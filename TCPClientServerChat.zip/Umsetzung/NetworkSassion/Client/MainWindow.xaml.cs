﻿
using System.Windows;
using Secure;
using static System.Net.WebRequestMethods;

namespace Client
{
    

    public partial class MainWindow : Window

    {
        

        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
            
        }

       
    }
}
